# Day And Night Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/shantanu-jana/pen/wvyWwwN](https://codepen.io/shantanu-jana/pen/wvyWwwN).

Day and night toggle switch using HTML and CSS.